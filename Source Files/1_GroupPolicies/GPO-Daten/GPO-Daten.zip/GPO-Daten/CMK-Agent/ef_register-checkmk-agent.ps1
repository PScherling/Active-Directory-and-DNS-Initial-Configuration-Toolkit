<#
.SYNOPSIS

.DESCRIPTION
    
.LINK
    
.NOTES
          FileName: ef_register-checkmk-agent.ps1
          Solution: 
          Author: Patrick Scherling
          Contact: @Patrick Scherling
          Primary: @Patrick Scherling
          Created: 2025-08-07
          Modified: 2025-08-07

          Version - 0.0.1 - () - Finalized functional version 1.
          

          TODO:
		  
		
.Example
#>

Clear-Host
$filetimestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$global:WarningCount = 0
$global:ErrorCount = 0
$destdir = "C:\Program Files (x86)\checkmk\service"
$hostname = $env:COMPUTERNAME
$sitename = ""
$snmpserver = ""
$logPath = Join-Path -Path "$($PSScriptRoot)\Logs\" -ChildPath "$($hostname)_ef_register-checkmk-agent_$($filetimestamp).log"
# Read the file
$fileContent = Get-Content -Path "$($PSScriptRoot)\server-information.txt" -ErrorAction Continue

# Tracking Warnings
function Write-TrackedWarning {
    param([string]$Message)
    $global:WarningCount++
    Write-Host -ForegroundColor Yellow $Message
}

# Tracking Errors
function Write-TrackedError {
    param([string]$Message)
    $global:ErrorCount++
    Write-Host -ForegroundColor Red $Message
}

# Logging function
function Write-Log {
    param([string]$msg)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $msg" | Out-File -FilePath $logPath -Append
    #Write-Host $msg
}

if (-not (Test-Path "$($PSScriptRoot)\Logs\")) {
    Write-Log "Log Directory not found. Creating '$($PSScriptRoot)\Logs\'"
    try{
        New-Item -ItemType Directory -Path "$($PSScriptRoot)\Logs\" | Out-Null
    } catch{
        Write-TrackedError "Log directory could not be created. $_"
        Write-Log "ERROR: Log directory could not be created. $_"
        break
    }
}


function register-checkmk {
    param (
        [string]$snmpserver,
        [string]$sitename
    )

    Write-Host -ForegroundColor Red "
       .-://///:-.
     -://:-...-//   .       
    -///-         ///       EEEEEEE UU   UU RRRRRR   OOOOO  FFFFFFF UU   UU NN   NN KK  KK
    ///:         :///       EE      UU   UU RR   RR OO   OO FF      UU   UU NNN  NN KK KK
    ///:         :///       EEEEE   UU   UU RRRRRR  OO   OO FFFF    UU   UU NN N NN KKKK
    -///-       -///-       EE      UU   UU RR  RR  OO   OO FF      UU   UU NN  NNN KK KK
     -://:-...-://:-        EEEEEEE  UUUUU  RR   RR  OOOO0  FF       UUUUU  NN   NN KK  KK
       *-://///:-*
"
	Write-Host -ForegroundColor Cyan "
    +----+ +----+     
    |####| |####|     
    |####| |####|       WW   WW II NN   NN DDDDD   OOOOO  WW   WW  SSSS
    +----+ +----+       WW   WW II NNN  NN DD  DD OO   OO WW   WW SS
    +----+ +----+       WW W WW II NN N NN DD  DD OO   OO WW W WW  SSS
    |####| |####|       WWWWWWW II NN  NNN DD  DD OO   OO WWWWWWW    SS
    |####| |####|       WW   WW II NN   NN DDDDD   OOOO0  WW   WW SSSS
    +----+ +----+       
"

    Write-Host "-----------------------------------------------------------------------------------"
    Write-Host "              Register CheckMK Agent"
    Write-Host "-----------------------------------------------------------------------------------"
    

    try{
        # ./check_mk_agent updater register -s  $snmpserver -i $sitename  -p https -U automation --secret 11cd8644-44d4-418a-a1c3-cc2626a52c2e -H $hostname -v
        Start-Process -FilePath "$($destdir)\check_mk_agent.exe" -ArgumentList "updater register -s $($snmpserver) -i $($sitename) -p https -U automation --secret '11cd8644-44d4-418a-a1c3-cc2626a52c2e' -H $($hostname)  -v" -Wait -NoNewWindow
    } catch{
        Write-TrackedError "CheckMK service registration failed - $_"
        Write-Log "ERROR: CheckMK service registration failed - $_"
    }

    try{
        # ./check_mk_agent updater -v
         Start-Process -FilePath "$($destdir)\check_mk_agent.exe" -ArgumentList "updater -v" -Wait -NoNewWindow
    } catch{
        Write-TrackedWarning "CheckMK service update failed - $_"
        Write-Log "WARNING: CheckMK service update failed - $_"
    }
}


Write-Log "=== Starting progress... ==="

if (-not (Test-Path $destdir)) {
    Write-TrackedError "CheckMK installation directory '$($destdir)' not found."
    Write-Log "ERROR: CheckMK installation directory '$($destdir)' not found."
    exit
}
else{
    if([string]::IsNullOrEmpty($fileContent)){
        Write-TrackedWarning "CheckMK information file '$($fileContent)' not found."
        Write-Log "WARNING: CheckMK installation directory '$($fileContent)' not found."

        Write-Log "Waiting for snmp server information..."
        do{
            $snmpserver = Read-Host " Enter SNMP-Server IP address"
            Write-Log " User Input: $snmpserver"
        } while([string]::IsNullOrEmpty($snmpserver) -or $snmpserver -notmatch "^[0-9\.]+$")


        Write-Log "Waiting for site information..."
        do{
            $sitename = Read-Host -Prompt " Enter site name"
            Write-Log "User input for site name: $sitename"
        } while([string]::IsNullOrEmpty($sitename))
    }
    else{
        # Initialize a hashtable to store the values
        $info = @{}

        # Parse each line and add to hashtable
        foreach ($line in $fileContent) {
            if ($line -match "^\s*(\w+):\s*(.+)$") {
                $key = $matches[1]
                $value = $matches[2]
                $info[$key] = $value
            }
        }

        # Now you can access values like this:
        $snmpserver = $info["snmpserver"]
        $sitename = $info["sitename"]
    }

    register-checkmk -snmpserver $snmpserver -sitename $sitename
}



Write-Log "=== Finished progress... ==="

Write-Host "
=== Summary ==="
Write-Host -ForegroundColor Yellow "    Total Warnings: $($global:WarningCount)"
Write-Host -ForegroundColor Red "    Total Errors: $($global:ErrorCount)"
if($global:WarningCount -gt 0 -or $global:ErrorCount -gt 0){
    Write-Host "    For more details, look at the logfile:
    '$($logPath)'"
}
Write-Host "    Completed at: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

Write-Log "=== Summary ==="
Write-Log "Total Warnings: $($global:WarningCount)"
Write-Log "Total Errors: $($global:ErrorCount)"
Write-Log "Completed at: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

Read-Host " Press any key to leave"


