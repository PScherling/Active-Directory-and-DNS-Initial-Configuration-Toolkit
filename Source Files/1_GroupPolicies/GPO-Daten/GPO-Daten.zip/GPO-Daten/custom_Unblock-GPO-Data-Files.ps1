<#
.SYNOPSIS
    
.DESCRIPTION
	Unblocks Files from specific directory.
    
.LINK
    
.NOTES
          FileName: custom_Unblock-GPO-Data-Files.ps1
          Solution: 
          Author: Patrick Scherling
          Contact: @Patrick Scherling
          Primary: @Patrick Scherling
          Created: 2025-07-10
          Modified: 2025-10-17

          Version - 0.0.1 - () - Finalized functional version 1.
		  Version - 0.0.2 - () - Fixed: Bug by User Input that gets ignored.

          TODO:
		  
		
.Example
#>

# Function to log messages with timestamps
function Write-Log {
    param (
		[string]$Message
	)
	$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
	$logMessage = "[$timestamp] $Message"
	#Write-Output $logMessage
	$logMessage | Out-File -FilePath $logFile -Append
}


function Unblock_EF-GPO-Data-Files($Path) {
    Write-Log "Unblocking Files..."
	
    Get-ChildItem -Path $Path -Recurse -File -Force | ForEach-Object {
        Write-Log "Unblocking File: $($_.FullName)"
        Write-Host "Unblocking File: $($_.FullName)"
        try{            
            Unblock-File -Path $_.FullName #-WhatIf
        }
        catch{
            Write-Warning "Failed to unblock: $($_.FullName)"
            Write-Log "Failed to unblock: $($_.FullName)"
        }
        finally {
            Write-Log "File Unblocked."
            Write-Host -ForegroundColor Green "File Unblocked."
        }
    }
    
    # End logging
    Write-Log "End of configuration process."
	
	Read-Host -Prompt " Press any key to leave"
}




Clear-Host
# Log file path
$logFile = "C:\_it\Unblocking_GPO-Data-Files.log"

# Start logging
Write-Log " Starting configuration process..."


Write-Host -ForegroundColor Cyan "
    +----+ +----+     
    |####| |####|     
    |####| |####|       WW   WW II NN   NN DDDDD   OOOOO  WW   WW  SSSS
    +----+ +----+       WW   WW II NNN  NN DD  DD OO   OO WW   WW SS
    +----+ +----+       WW W WW II NN N NN DD  DD OO   OO WW W WW  SSS
    |####| |####|       WWWWWWW II NN  NNN DD  DD OO   OO WWWWWWW    SS
    |####| |####|       WW   WW II NN   NN DDDDD   OOOO0  WW   WW SSSS
    +----+ +----+       
"
Write-Host "-----------------------------------------------------------------------------------"

do {
    Write-Host "`n Please enter the path to unblock the files or press Enter to use the default location."
    $rawInput = Read-Host " (Default: 'D:\GPO-Daten')"
    Write-Log " User Input for directory: $rawInput"

    # Resolve default vs custom
    if ([string]::IsNullOrWhiteSpace($rawInput)) {
        $destPath = "D:\GPO-Daten"
    } else {
        $destPath = $rawInput
    }

    Write-Host -ForegroundColor Yellow " Directory is '$destPath'"
    Write-Log " Directory is '$destPath'"

    # Validate directory exists
    if (-not (Test-Path -Path $destPath -PathType Container)) {
        Write-Host -ForegroundColor Yellow " WARNING: The directory '$destPath' does not exist."
        Write-Log  " WARNING: The directory '$destPath' does not exist."
        $destPath = $null
        continue
    }

    # Confirm
    $continue = Read-Host " Do you want to continue? (y/n)"

} while ([string]::IsNullOrWhiteSpace($destPath) -or ($continue -notmatch '^(?i)y$|^(?i)n$'))

if ($continue -match '^(?i)y$') {
    Unblock_EF-GPO-Data-Files -Path $destPath
    Write-Log " Unblock_GPO-Data-Files executed for '$destPath'."
} else {
    Write-Log " User chose to abort."
}

