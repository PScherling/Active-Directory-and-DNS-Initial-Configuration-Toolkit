# 16.08.2022
# pscherling@eurofunk.com
# 
# Lokale SNMP Feature Installation von Windows
# 
# 
# 
# Version 0.1
#
# Changelog:
# 
#
#
#
$installed = "false";
$logfile = 'C:\_it\snmp-service-activation-log.txt' #Optional

#All Output in Logfile - Optional
$( #--> Deaktivate with hash

if (Get-WindowsFeature -name "SNMP-Service" | fl Installed | Where-Object {$_.Installed -eq $installed})
{
    Write-Host "-----------------------------------------------"
    Write-Host " Current Installation Status is: " $installed -ForegroundColor Red
    #Read-Host -Prompt "Press any key to install Service"

    Install-WindowsFeature -name "SNMP-Service" -ErrorAction stop

    Write-Host "-----------------------------------------------"
    Write-Host "Service successfully installed" -ForegroundColor Green
} 
else
{
    Write-Host "-----------------------------------------------"
    Write-Host " Current Installation Status is true" `n "Service is already installed on this system" `n "Nothing more to do..." -ForegroundColor Green
}


) *>> $logfile #--> Logfile Output - Deactivate with hash