<#
.SYNOPSIS

.DESCRIPTION
		  HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System
		  --> Wallpaper Value sets the Wallpaper FileName
		  --> WallpaperStyle sets how the Wallpaper should be applied
			- Center  --> 0
			- Tile    --> 1
			- Stretch --> 2
			- Fit     --> 3
			- Fill    --> 4
			- Span    --> 5
			
		  Set the eurofunk wallpaper based on primary display resolution.	
    
.LINK
          https://en.wikipedia.org/wiki/Display_resolution_standards
		  https://www.tenforums.com/tutorials/91437-specify-default-desktop-background-windows-10-a.html
    
.NOTES
          FileName: custom_SetWallpaper.ps1
          Solution: 
          Author: Patrick Scherling
          Contact: @Patrick Scherling
          Primary: @Patrick Scherling
          Created: 
          Modified: 2025-01-28

          Version - 0.0.1 - () - Finalized functional version 1.

          

          TODO:
		  
		
.Example
#>

function SetWallpaper {
	
	Clear-Host

    # Log file path
    $logFile = "C:\_it\SetWallpaper.log"
	
	# Function to log messages with timestamps
    function Write-Log {
        param (
            [string]$Message
        )
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $logMessage = "[$timestamp] $Message"
        #Write-Output $logMessage
        $logMessage | Out-File -FilePath $logFile -Append
    }

    Write-Log "
 
 Starting configuration process..."

    Add-Type -AssemblyName System.Windows.Forms
	$Screens = [System.windows.Forms.Screen]::AllScreens
    
    # Wallpaper files mapping based on screen resolution
	$wallpapers = @{
		"1024x768" = "eurofunk_1280-720.jpg"
		"800x600" = "eurofunk_1280-720.jpg"
		"3840x2400" = "eurofunk_3840-2160.jpg"
		"3200x2048" = "eurofunk_1920-1080.jpg"
		"2880x1800" = "eurofunk_1920-1080.jpg"
		"2560x1600" = "eurofunk_1920-1080.jpg"
		"1920x1200" = "eurofunk_1920-1080.jpg"
		"1440x900" = "eurofunk_1280-720.jpg"
		"1280x800" = "eurofunk_1280-720.jpg"
		"7680x4320" = "eurofunk_3840-2160.jpg"
		"3840x2160" = "eurofunk_3840-2160.jpg"
		"3200x1800" = "eurofunk_1920-1080.jpg"
		"2560x1440" = "eurofunk_1920-1080.jpg"
		"1920x1080" = "eurofunk_1920-1080.jpg"
		"1600x900" = "eurofunk_1280-720.jpg"
		"1280x720" = "eurofunk_1280-720.jpg"
		"7018x1974" = "eurofunk_7018-1974.jpg"
		"5120x1440" = "eurofunk_5120-1440.jpg"
		"3440x1440" = "eurofunk_3840-1080.jpg"
		"2560x1080" = "eurofunk_3840-1080.jpg"
	}



    Write-Log " Screens count: $($Screens.Count)"
	Write-Log " Get Display Information"
	foreach($screen in $Screens){
		$name = $screen.DeviceName
		# Remove '\\.' from the beginning of the device name
        $name = $name.Replace('\','')
        $name = $name.Replace('.','')
		$width = $screen.Bounds.Width
		$height = $screen.Bounds.Height
		Write-Log " Device: $name"
		Write-Log " Resolution: $($width)x$($height)"
	}

	$Primary = $Screens | Where-Object { $_.Primary -eq $True }
	$PrimaryWidth = $Primary.Bounds.Width
	$PrimaryHeight = $Primary.Bounds.Height
	#Write-Host "Primary Display Resolution is set to: $($width)x$($height)"
	$currentRes = "$($PrimaryWidth)x$($PrimaryHeight)"
	
	Write-Log " Primary Display Resolution is: $currentRes"
    
    $WallpaperFiles = Get-ChildItem -Path "C:\Windows\Web\Wallpaper\Windows\" -Name "eurofunk_*"

    Write-Log " Wallpaper count: $($WallpaperFiles.Count)"
    if($WallpaperFiles.Count -ne 0){
        Write-Log " Available Wallpapers:"
        
        foreach($wallpaper in $WallpaperFiles){
            Write-Log " - $($wallpaper.PSChildName)"
        }
    }
    else{
        Write-Log " ERROR: There are no wallpapers available to use!"
        exit
    }

	# Select wallpaper based on resolution
	Write-Log "Select wallpaper based on resolution."
	$regValue = if ($wallpapers.ContainsKey($currentRes)) {
		$wallpapers[$currentRes]
	} else {
		Write-Log "Resolution not found. Defaulting to 1920x1080 wallpaper."
		"eurofunk_1920-1080.jpg"
	}

	#$wallRegPath = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
	$wallRegPath = "HKCU:\Control Panel\Desktop"

	# Ensure registry path exists
	Write-Log "Ensure registry path exists."
	Write-Log "Checking '$wallRegPath'."
	if (-not (Test-Path -Path $wallRegPath)) {
		Write-Log "Creating '$wallRegPath'."
		try{
			New-Item -Path $wallRegPath -Force -ErrorAction Continue
		}
		catch{
			Write-Log "ERROR: '$wallRegPath' could not be created."
		}
	}
	else{
		Write-Log "Registry Item '$wallRegPath' exists."
	}
	

	# Set wallpaper registry values
	Write-Log "Set wallpaper registry values."
    Write-Log "Setting Wallpaper '$regValue'"
	try{
		Set-ItemProperty -Path $wallRegPath -Name Wallpaper -Value "C:\Windows\Web\Wallpaper\Windows\$regValue" -ErrorAction Continue
	}
	catch{
		Write-Log "ERROR: Registry item '$wallRegPath' Wallpaper could not be set to 'C:\Windows\Web\Wallpaper\Windows\$regValue'."
	}
	try{
		Set-ItemProperty -Path $wallRegPath -Name WallpaperStyle -Value 4 -ErrorAction Continue
	}
	catch{
		Write-Log "ERROR: Registry item '$wallRegPath' WallpaperStle could not be set to '4'."
	}
	

}

SetWallpaper